using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.User_Login
{
    public class User_LoginModel : PageModel
    {
        [BindProperty]

        public Employee Employee { get; set; }

        public string Message { get; set; }

        public string SessionID;
        public IActionResult OnPost()
        {
            if(!ModelState.IsValid)
            {
                return Page();
            }

            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine(Employee.Employee_Email);
            Console.WriteLine(Employee.Employee_Pswd);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT * FROM Employee WHERE Employee_Email = @UName AND Employee_Pswd = @Pwd";

                command.Parameters.AddWithValue("@UName", Employee.Employee_Email);
                command.Parameters.AddWithValue("@Pwd", Employee.Employee_Pswd);

                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Employee.Employee_ID = reader.GetInt32(0);
                    Employee.Employee_F_Name = reader.GetString(1);
                    Employee.Employee_L_Name = reader.GetString(2);
                    Employee.Employee_Email = reader.GetString(3);
                    Employee.Employee_Pswd = reader.GetString(4);
                    Employee.FileName = reader.GetString(5); 
                }

                if (!string.IsNullOrEmpty(Employee.Employee_F_Name))
                {
                    SessionID = HttpContext.Session.Id;
                    HttpContext.Session.SetString("sessionID", SessionID);
                    HttpContext.Session.SetInt32("employeeid", Employee.Employee_ID);
                    HttpContext.Session.SetString("email", Employee.Employee_Email);
                    HttpContext.Session.SetString("fname", Employee.Employee_F_Name);
                    HttpContext.Session.SetString("lname", Employee.Employee_L_Name);
                    HttpContext.Session.SetString("filename", Employee.FileName);
                    HttpContext.Session.SetString("pswd", Employee.Employee_Pswd);



                    if (Employee.Employee_L_Name == "Fleming")
                    {
                        return RedirectToPage("/Manager_Login/Login");
                    }
                    else
                    {
                        return RedirectToPage("/User_Pages/UserIndex");
                    }


                }
                else
                {
                    Message = "Invalid Username and/or Password!";
                    return Page();
                }

            }



        }
    }
}

