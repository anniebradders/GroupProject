using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Shifts
{
    public class ViewModel : PageModel
    {
        public List<Shift> GroupProject { get; set; }
        public void OnGet()
        {
            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT * FROM Shift";

                SqlDataReader reader = command.ExecuteReader(); //SqlDataReader is used to read record from a table

                GroupProject = new List<Shift>(); //this object of list is created to populate all records from the table

                while (reader.Read())
                {
                    Shift record = new Shift(); //a local var to hold a record temporarily
                    record.Shift_ID = reader.GetInt32(0); //getting the first field from the table
                    record.Shift_Date = reader.GetString(1); //getting the second field from the table
                    record.Shift_S_Time = reader.GetString(2); //getting the third field from the table
                    record.Shift_E_Time = reader.GetString(3);
                    record.Shift_Hour = reader.GetInt32(4);
                    record.Shift_employee = reader.GetString(5);

                    GroupProject.Add(record); //adding the single record into the list
                }

                // Call Close when done reading.
                reader.Close();


            }
        }
    }
}

