using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.UploadFile
{
    public class DeleteModel : PageModel
    {
        [BindProperty]

        public Employee GroupProject { get; set; }
        public IActionResult OnGet(int? id)
        {

            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT FileName FROM Employee WHERE Employee_ID = @ID";
                command.Parameters.AddWithValue("@ID", id);

                SqlDataReader reader = command.ExecuteReader();

                GroupProject = new Employee();

                while (reader.Read())
                {
                    GroupProject.FileName = reader.GetString(0);
                }

            }

            conn.Close();

            return Page();
        }

        public IActionResult OnPost()
        {
            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Employee SET FileName = 'default.jpg'";
                command.Parameters.AddWithValue("@ID", GroupProject.Employee_ID);
                command.ExecuteNonQuery();
            }

            conn.Close();
            return RedirectToPage("/Employees/View");
        }


    }
}

