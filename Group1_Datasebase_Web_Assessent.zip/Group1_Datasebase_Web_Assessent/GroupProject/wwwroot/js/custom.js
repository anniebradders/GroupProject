﻿function pop() {
	if (window.confirm("ARE YOU READY TO BE FESTIVE?")) {
		window.location.href = "https://www.youtube.com/watch?v=aAkMkVFwAoo";
	};
}

function change() {

    var i;
    var x = document.getElementsByClassName("slides");
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
    }
    slideIndex++;
    if (slideIndex > x.length) { slideIndex = 1 }
    x[slideIndex - 1].style.display = "block";
    setTimeout(change, 2000);
}

var date = setInterval(timer, 1000);

function timer() {
    var d = new Date();
    document.getElementById("time").innerHTML = d.toLocaleTimeString();
}