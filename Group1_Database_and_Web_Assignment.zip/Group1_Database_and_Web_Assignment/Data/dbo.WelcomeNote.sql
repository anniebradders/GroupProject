﻿CREATE TABLE [dbo].[WelcomeNote] (
    [Id]              INT            IDENTITY (1, 1) NOT NULL,
    [DateOfUpdate]    NVARCHAR (50)  NULL,
    [Contents]        NVARCHAR (MAX) NULL,
    [ManagerUpdating] NVARCHAR (50)  NULL,
    PRIMARY KEY CLUSTERED ([Id] ASC)
);
