using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Manager_Login
{
    public class LoginModel : PageModel
    {
        [BindProperty]

        public Manager Manager { get; set; }

        public string Message { get; set; }

        public string SessionID;
        public IActionResult OnPost()
        {

            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine(Manager.Manager_Username);
            Console.WriteLine(Manager.Manager_Pswd);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT Manager_F_Name, Manager_Username, Manager_L_Name FROM Manager WHERE Manager_Username = @UName AND Manager_Pswd = @Pwd";

                command.Parameters.AddWithValue("@UName", Manager.Manager_Username);
                command.Parameters.AddWithValue("@Pwd", Manager.Manager_Pswd);

                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Manager.Manager_F_Name = reader.GetString(0);
                    Manager.Manager_Username = reader.GetString(1);
                    Manager.Manager_Pswd = reader.GetString(2);
                }

                if (!string.IsNullOrEmpty(Manager.Manager_F_Name))
                {
                    SessionID = HttpContext.Session.Id;
                    HttpContext.Session.SetString("sessionID", SessionID);
                    HttpContext.Session.SetString("username", Manager.Manager_Username);
                    HttpContext.Session.SetString("fname", Manager.Manager_F_Name);

                    if (Manager.Manager_L_Name == "User")
                    {
                        return RedirectToPage("/Managers/View");
                    }
                    else
                    {
                        return RedirectToPage("/Managers/View");
                    }


                }
                else
                {
                    Message = "Invalid Username and/or Password!";
                    return Page();
                }

            }



        }
    }
}
