using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Shifts
{
    public class Del_SelModel : PageModel
    {
        [BindProperty]
        public List<Shift> Mod { get; set; } //this variable is used for the form in html page


        [BindProperty]
        public List<bool> IsSelect { get; set; } //this is needed to allow the user to select the checkbox in the form of html page


        public List<Shift> ModToDelete { get; set; } //this variable is a list to collect the selected modules to be deleted

        public IActionResult OnGet()
        {
            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Shift";

                SqlDataReader reader = command.ExecuteReader();

                Mod = new List<Shift>(); //create an object to collect records
                IsSelect = new List<bool>();
                while (reader.Read())
                {
                    Shift rec = new Shift();
                    rec.Shift_ID = reader.GetInt32(0); //the primary key in the table. This is mandatory to have.
                    rec.Shift_Date = reader.GetString(1);
                    rec.Shift_S_Time = reader.GetString(2);
                    rec.Shift_E_Time = reader.GetString(3);
                    rec.Shift_Hour = reader.GetInt32(4);
                    rec.Shift_employee = reader.GetString(5);

                    Mod.Add(rec);
                    IsSelect.Add(false);// every record should have 1 checkbox, but we set to false first!
                    //You can populate all the fields of Module. For this example, we display a few fields.
                }
            }

            return Page();

        }

        public IActionResult OnPost()
        {
            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            ModToDelete = new List<Shift>();//create the object for Module to be deleted. This variable now an empty list
            for (int i = 0; i < Mod.Count; i++) //Read all rows from Module. Each row has a checkbox!
            {
                if (IsSelect[i] == true) //if the checkbox of the row is true
                {
                    ModToDelete.Add(Mod[i]); //collect the item for the row
                }
            }

            Console.WriteLine("Module to be deleted : ");

            for (int i = 0; i < ModToDelete.Count(); i++)
            {
                Console.WriteLine(ModToDelete[i].Shift_ID); // we need to write the SQL statement to delete the module based on this Id
                Console.WriteLine(ModToDelete[i].Shift_Date);
                Console.WriteLine(ModToDelete[i].Shift_S_Time); //We can also use this as the key to delete the module (depending on Db design)
                Console.WriteLine(ModToDelete[i].Shift_E_Time);
                Console.WriteLine(ModToDelete[i].Shift_Hour);
                Console.WriteLine(ModToDelete[i].Shift_employee);
                //We can have more fields 
            }

            for (int i = 0; i < ModToDelete.Count(); i++)
            {

                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandText = @"DELETE FROM Shift WHERE Shift_ID = @ModID";
                    command.Parameters.AddWithValue("@ModID", ModToDelete[i].Shift_ID);
                    command.ExecuteNonQuery();
                }
            }

            return RedirectToPage("/Shifts/View");


        }


    }
}
