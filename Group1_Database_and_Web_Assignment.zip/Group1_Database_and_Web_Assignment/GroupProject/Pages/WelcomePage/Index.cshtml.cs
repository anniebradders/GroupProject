using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.WelcomePage
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public WelcomeNote GroupProject { get; set; }
       
       

        public IActionResult OnPost()
        {
            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "INSERT INTO WelcomeNote ( Contents, DateOfUpdate,ManagerUpdating) VALUES ( @Wc,  @Wd,  @Wm) ";
                command.Parameters.AddWithValue("@Wc", GroupProject.WelcomeContents);
                command.Parameters.AddWithValue("@Wd", GroupProject.DateOfUpdate);
                command.Parameters.AddWithValue("@Wm", GroupProject.ManagerUpdating);
                Console.WriteLine(GroupProject.WelcomeContents);
                Console.WriteLine(GroupProject.DateOfUpdate);
                Console.WriteLine(GroupProject.ManagerUpdating);


                command.ExecuteNonQuery();
            }

            conn.Close();

            return Page();
        }
    }
}
