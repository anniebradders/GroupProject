using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Managers
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public Manager GroupProject { get; set; }
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"INSERT INTO Manager (Manager_F_Name, Manager_L_Name, Manager_Username, Manager_Pswd) VALUES (@MFName, @MLName, @MUsername, @MPswd)";


                command.Parameters.AddWithValue("@MFName", GroupProject.Manager_F_Name);
                command.Parameters.AddWithValue("@MLName", GroupProject.Manager_L_Name);
                command.Parameters.AddWithValue("@MUsername", GroupProject.Manager_Username);
                command.Parameters.AddWithValue("@MPswd", GroupProject.Manager_Pswd);

                Console.WriteLine(GroupProject.Manager_F_Name);
                Console.WriteLine(GroupProject.Manager_L_Name);
                Console.WriteLine(GroupProject.Manager_Username);
                Console.WriteLine(GroupProject.Manager_Pswd);

                command.ExecuteNonQuery();
            }

            return RedirectToPage("/Managers/View");
        }
    }
}
