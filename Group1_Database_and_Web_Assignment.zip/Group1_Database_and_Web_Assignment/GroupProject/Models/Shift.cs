﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GroupProject.Models
{
    public class Shift
    {
        [Display(Name = "Shift ID")]
        public int Shift_ID { get; set; }

        [Display(Name = "Date")]
        public string Shift_Date { get; set; }

        [Display(Name = "Start Time")]
        public string Shift_S_Time { get; set; }

        [Display(Name = "End Time")]
        public string Shift_E_Time { get; set; }

        [Display(Name = "Number of Hours")]
        public int Shift_Hour { get; set; }

        [Display(Name = "Employee Email")]
        public string Shift_employee { get; set; }
    }
}
