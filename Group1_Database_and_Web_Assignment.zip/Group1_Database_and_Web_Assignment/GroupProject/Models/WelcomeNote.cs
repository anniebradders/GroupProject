﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroupProject.Models
{
    public class WelcomeNote
    {
       public int id { get; set; }
        public string WelcomeContents { get; set; }
        public string ManagerUpdating { get; set; }
        public string DateOfUpdate { get; set; }

    }
}
