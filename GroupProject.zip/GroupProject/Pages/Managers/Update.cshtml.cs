using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Managers
{
    public class UpdateModel : PageModel
    {
        [BindProperty]
        public Manager GroupProject { get; set; }
        public IActionResult OnGet(int? id)
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();


            GroupProject = new Manager();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Manager WHERE Manager_ID = @ID";

                command.Parameters.AddWithValue("@ID", id);
                Console.WriteLine("The id : " + id);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    GroupProject.Manager_ID = reader.GetInt32(0);
                    GroupProject.Manager_F_Name = reader.GetString(1);
                    GroupProject.Manager_L_Name = reader.GetString(2);
                    GroupProject.Manager_Username = reader.GetString(3);
                    GroupProject.Manager_Pswd = reader.GetString(4);
                }


            }

            conn.Close();

            return Page();

        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine("Manager ID : " + GroupProject.Manager_ID);
            Console.WriteLine("First Name : " + GroupProject.Manager_F_Name);
            Console.WriteLine("Last Name : " + GroupProject.Manager_L_Name);
            Console.WriteLine("Email : " + GroupProject.Manager_Username);
            Console.WriteLine("Password : " + GroupProject.Manager_Pswd);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Manager SET Manager_F_Name = @MFName, Manager_L_Name = @MLName, Manager_Username = @MUser, Manager_Pswd = @MPswd WHERE Manager_ID = @MID";

                command.Parameters.AddWithValue("@MID", GroupProject.Manager_ID);
                command.Parameters.AddWithValue("@MFName", GroupProject.Manager_F_Name);
                command.Parameters.AddWithValue("@MLName", GroupProject.Manager_L_Name);
                command.Parameters.AddWithValue("@MUser", GroupProject.Manager_Username);
                command.Parameters.AddWithValue("@MPswd", GroupProject.Manager_Pswd);

                command.ExecuteNonQuery();
            }

            conn.Close();

            return RedirectToPage("/Managers/View");
        }
    }
}
