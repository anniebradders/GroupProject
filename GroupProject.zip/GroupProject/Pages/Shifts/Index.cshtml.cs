using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Shifts
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public Shift GroupProject { get; set; }
        public void OnGet()
        {
        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"INSERT INTO Shift (Shift_Date, Shift_S_Time, Shift_E_Time, Shift_Hour) VALUES (@SDate, @SSTime, @SETime, @SHour)";


                command.Parameters.AddWithValue("@SDate", GroupProject.Shift_Date);
                command.Parameters.AddWithValue("@SSTime", GroupProject.Shift_S_Time);
                command.Parameters.AddWithValue("@SETime", GroupProject.Shift_E_Time);
                command.Parameters.AddWithValue("@SHour", GroupProject.Shift_Hour);


                Console.WriteLine(GroupProject.Shift_Date);
                Console.WriteLine(GroupProject.Shift_S_Time);
                Console.WriteLine(GroupProject.Shift_E_Time);
                Console.WriteLine(GroupProject.Shift_Hour);

                command.ExecuteNonQuery();
            }

            return RedirectToPage("/Shifts/View");
        }

    }
}

