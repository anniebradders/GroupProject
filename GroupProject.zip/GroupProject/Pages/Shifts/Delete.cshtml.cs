using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Shifts
{
    public class DeleteModel : PageModel
    {
        [BindProperty]

        public Shift GroupProject { get; set; }
        public IActionResult OnGet(int? id)
        {

            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Shift WHERE Shift_ID = @ID";
                command.Parameters.AddWithValue("@ID", id);

                SqlDataReader reader = command.ExecuteReader();

                GroupProject = new Shift();

                while (reader.Read())
                {
                    GroupProject.Shift_ID = reader.GetInt32(0);
                    GroupProject.Shift_Date = reader.GetString(1);
                    GroupProject.Shift_S_Time = reader.GetString(2);
                    GroupProject.Shift_E_Time = reader.GetString(3);
                    GroupProject.Shift_Hour = reader.GetInt32(4);
                }

            }

            conn.Close();

            return Page();
        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "DELETE Shift WHERE Shift_ID = @ID";
                command.Parameters.AddWithValue("@ID", GroupProject.Shift_ID);
                command.ExecuteNonQuery();
            }

            conn.Close();
            return RedirectToPage("/Shifts/View");
        }


    }
}

