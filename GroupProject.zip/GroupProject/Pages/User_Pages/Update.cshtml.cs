using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.User_Pages
{
    public class UpdateModel : PageModel
    {
        public string Email;
        public const string SessionKeyName1 = "email";

        public string FirstName;
        public const string SessionKeyName2 = "fname";

        public string LastName;
        public const string SessionKeyName3 = "lname";

        public string Pswd;
        public const string SessionKeyName4 = "pswd";

        public string FileName;
        public const string SessionKeyName5 = "filename";

        public string SessionID;
        public const string SessionKeyName6 = "sessionid";
        public IActionResult OnGet()
        {
            Email = HttpContext.Session.GetString(SessionKeyName1);
            FirstName = HttpContext.Session.GetString(SessionKeyName2);
            LastName = HttpContext.Session.GetString(SessionKeyName3);
            Pswd = HttpContext.Session.GetString(SessionKeyName4);
            FileName = HttpContext.Session.GetString(SessionKeyName5);
            SessionID = HttpContext.Session.GetString(SessionKeyName6);

            return Page();
        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine("First Name : " + FirstName);
            Console.WriteLine("Last Name : " + LastName);
            Console.WriteLine("Email : " + Email);
            Console.WriteLine("Password : " + Pswd);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Employee SET Employee_F_Name = @EFName, Employee_L_Name = @ELName, Employee_Email = @EEmail, Employee_Pswd = @EPswd WHERE Employee_ID = @EID";

                command.Parameters.AddWithValue("@EID", SessionID);
                command.Parameters.AddWithValue("@EFName", FirstName);
                command.Parameters.AddWithValue("@ELName", LastName);
                command.Parameters.AddWithValue("@EEmail", Email);
                command.Parameters.AddWithValue("@EPswd", Pswd);

                command.ExecuteNonQuery();
            }

            conn.Close();

            return RedirectToPage("/User_Pages/Details");
        }
    }
}
