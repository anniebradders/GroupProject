using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.User_Pages
{
    public class UserIndexModel : PageModel
    {

        public string Email;
        public const string SessionKeyName1 = "email";

        public string FirstName;
        public const string SessionKeyName2 = "fname";

        public string SessionID;
        public const string SessionKeyName3 = "sessionID";

        public List<Employee> GroupProject { get; set; }
        public IActionResult OnGet(int? id)
        {

            Email = HttpContext.Session.GetString(SessionKeyName1);
            FirstName = HttpContext.Session.GetString(SessionKeyName2);
            SessionID = HttpContext.Session.GetString(SessionKeyName3);

            if (string.IsNullOrEmpty(Email) && string.IsNullOrEmpty(FirstName) && string.IsNullOrEmpty(SessionID))
            {
                return RedirectToPage("/User_Login/Login");
            }
                           
        
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT * FROM Employee";

                SqlDataReader reader = command.ExecuteReader(); //SqlDataReader is used to read record from a table

                GroupProject = new List<Employee>(); //this object of list is created to populate all records from the table

                while (reader.Read())
                {
                    Employee record = new Employee(); //a local var to hold a record temporarily
                    record.Employee_ID = reader.GetInt32(0); //getting the first field from the table
                    record.Employee_F_Name = reader.GetString(1); //getting the second field from the table
                    record.Employee_L_Name = reader.GetString(2); //getting the third field from the table
                    record.Employee_Email = reader.GetString(3);
                    record.Employee_Pswd = reader.GetString(4);

                    GroupProject.Add(record); //adding the single record into the list
                }
                // Call Close when done reading.
                
            }
            return Page();
        }
    }
}


