using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.User_Pages
{
    public class UserIndexModel : PageModel
    {

        public string Email;
        public const string SessionKeyName1 = "email";

        public string FirstName;
        public const string SessionKeyName2 = "fname";

        public string LastName;
        public const string SessionKeyName3 = "lname";

        public string SessionID;
        public const string SessionKeyName4 = "sessionID";

        public string FileName;
        public const string SessionKeyName5 = "filename";

        
        public IActionResult OnGet()
        {
            Email = HttpContext.Session.GetString(SessionKeyName1);
            FirstName = HttpContext.Session.GetString(SessionKeyName2);
            LastName = HttpContext.Session.GetString(SessionKeyName3);
            SessionID = HttpContext.Session.GetString(SessionKeyName4);
            FileName = HttpContext.Session.GetString(SessionKeyName5);

            if (string.IsNullOrEmpty(Email) && string.IsNullOrEmpty(FirstName) && string.IsNullOrEmpty(LastName) && string.IsNullOrEmpty(SessionID))
            {
                return RedirectToPage("/User_Login/Login");
            }
            return Page();
        }
    }
}


