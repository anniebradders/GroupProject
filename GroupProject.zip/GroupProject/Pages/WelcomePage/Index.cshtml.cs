using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.WelcomePage
{
    public class IndexModel : PageModel
    {
        private readonly IWebHostEnvironment _env;

        public IndexModel(IWebHostEnvironment env)
        {
            _env = env;
        }

        [BindProperty]
        public Welcome welcomeNote { get; set; }

        public IActionResult OnGet()
        {
            DateTime dd = DateTime.Now;
            string date = dd.ToString("dd/MM/yyyy");
            Console.WriteLine(date);
            welcomeNote = new Welcome();
            welcomeNote.DateUpdate = date;



            for (int i = 1; i < 1; i++) //there are 3 files
            {
                string WelcomeFile = "Welcome_para" + i + ".txt";
                var FileLocation = Path.Combine(_env.WebRootPath, "Welcome Files", WelcomeFile);
                try
                {   // Open the text file using a stream reader.
                    using (StreamReader sr = new StreamReader(FileLocation))
                    {
                        // Read the stream to a string, and write the string to the console.
                        String line = sr.ReadToEnd();
                        //Console.WriteLine(line);

                        if (i == 1)
                        {
                            welcomeNote.Message1 = line;
                            Console.WriteLine("The current text before update is : " + welcomeNote.Message1);
                        }
                    }
                }
                catch (IOException e)
                {
                    Console.WriteLine("The file could not be read:");
                    Console.WriteLine(e.Message);
                }
            }
            return Page();
        }
        public IActionResult OnPost()
        {
            for (int i = 1; i < 1; i++)
            {
                // Set a variable to the Documents path.
                string WelcomeFile = "Welcome_para" + i + ".txt";
                var FileLocation = Path.Combine(_env.WebRootPath, "Welcome Files", WelcomeFile);

                using (StreamWriter sw = new StreamWriter(FileLocation))
                {
                    if (i == 1)
                        sw.WriteAsync(welcomeNote.Message1);
                }
            }
            return RedirectToPage("/Index");
        }

    }
}
