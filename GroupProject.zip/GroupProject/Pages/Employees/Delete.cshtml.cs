using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Employees
{
    public class DeleteModel : PageModel
    {
        [BindProperty]

        public Employee GroupProject { get; set; }
        public IActionResult OnGet(int? id)
        {

            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Employee WHERE Employee_ID = @ID";
                command.Parameters.AddWithValue("@ID", id);

                SqlDataReader reader = command.ExecuteReader();

                GroupProject= new Employee();

                while (reader.Read())
                {
                    GroupProject.Employee_ID = reader.GetInt32(0);
                    GroupProject.Employee_F_Name = reader.GetString(1);
                    GroupProject.Employee_L_Name = reader.GetString(2);
                    GroupProject.Employee_Email = reader.GetString(3);
                    GroupProject.Employee_Pswd = reader.GetString(4);
                }

            }

            conn.Close();

            return Page();
        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "DELETE Employee WHERE Employee_ID = @ID";
                command.Parameters.AddWithValue("@ID", GroupProject.Employee_ID);
                command.ExecuteNonQuery();
            }

            conn.Close();
            return RedirectToPage("/Employees/View");
        }


    }
}
