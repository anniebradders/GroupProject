using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Employees
{
    public class UpdateModel : PageModel
    {
        [BindProperty]
        public Employee GroupProject { get; set; }
        public IActionResult OnGet(int? id)
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();


            GroupProject = new Employee();

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "SELECT * FROM Employee WHERE Employee_ID = @ID";

                command.Parameters.AddWithValue("@ID", id);
                Console.WriteLine("The id : " + id);

                SqlDataReader reader = command.ExecuteReader();

                while (reader.Read())
                {
                    GroupProject.Employee_ID= reader.GetInt32(0);
                    GroupProject.Employee_F_Name = reader.GetString(1);
                    GroupProject.Employee_L_Name = reader.GetString(2);
                    GroupProject.Employee_Email = reader.GetString(3);
                    GroupProject.Employee_Pswd = reader.GetString(4);
                    
                }


            }

            conn.Close();

            return Page();

        }

        public IActionResult OnPost()
        {
            string DbConnection = @"Data Source=(localdb)\MSSQLLocalDB;Initial Catalog=Assignment;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine("Employee ID : " + GroupProject.Employee_ID);
            Console.WriteLine("First Name : " + GroupProject.Employee_F_Name);
            Console.WriteLine("Last Name : " + GroupProject.Employee_L_Name);
            Console.WriteLine("Email : " + GroupProject.Employee_Email);
            Console.WriteLine("Password : " + GroupProject.Employee_Pswd);
            

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = "UPDATE Employee SET Employee_F_Name = @EFName, Employee_L_Name = @ELName, Employee_Email = @EEmail, Employee_Pswd = @EPswd WHERE Employee_ID = @EID";

                command.Parameters.AddWithValue("@EID", GroupProject.Employee_ID);
                command.Parameters.AddWithValue("@EFName", GroupProject.Employee_F_Name);
                command.Parameters.AddWithValue("@ELName", GroupProject.Employee_L_Name);
                command.Parameters.AddWithValue("@EEmail", GroupProject.Employee_Email);
                command.Parameters.AddWithValue("@EPswd", GroupProject.Employee_Pswd);

                command.ExecuteNonQuery();
            }

            conn.Close();

            return RedirectToPage("/Employees/View");
        }
    }
}
