﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GroupProject.Models
{
    public class Manager
    {
        [Display(Name = "Manager ID")]
        public int Manager_ID { get; set; }

        [Display(Name = "First Name")]
        public string Manager_F_Name { get; set; }

        [Display(Name = "Surname")]
        public string Manager_L_Name { get; set; }

        [Display(Name = "Username")]
        public string Manager_Username { get; set; }

        [Display(Name = "Password")]
        public string Manager_Pswd { get; set; }

    }
}
