﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GroupProject.Models
{
    public class Welcome
    {
        [Required]
        public int Manager_ID { get; set; }

        [Required]
        [Display(Name = "Message Para 1")]
        public string Message1 { get; set; }

        [Required]
        [Display(Name = "Date Update")]
        public string DateUpdate { get; set; }


        [Required]
        [Display(Name = "User")]
        public string Manager_F_Name { get; set; }

    }
}
