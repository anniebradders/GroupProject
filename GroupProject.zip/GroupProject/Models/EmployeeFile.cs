﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace GroupProject.Models
{
    public class EmployeeFile
    {
        public int Employee_ID { get; set; }
        public string FileName { get; set; }

    }
}
