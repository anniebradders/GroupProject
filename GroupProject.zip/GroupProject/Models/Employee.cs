﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace GroupProject.Models
{
    public class Employee
    {
        [Display (Name = "Employee ID")]
        public int Employee_ID { get; set; }

        [Display(Name = "First Name")]
        public string Employee_F_Name { get; set; }

        [Display(Name = "Surname")]
        public string Employee_L_Name { get; set; }

        [Display(Name = "Email")]
        public string Employee_Email { get; set; }

        [Display(Name = "Password")]
        public string Employee_Pswd { get; set; }
    }
}
