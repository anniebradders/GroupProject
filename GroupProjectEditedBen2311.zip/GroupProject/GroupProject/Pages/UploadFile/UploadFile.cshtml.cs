using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.UploadFile
{
    public class UploadFileModel : PageModel
    {
        [BindProperty]

        public Employee GroupProject { get; set; }
        public IFormFile StdFile { get; set; }

        public readonly IWebHostEnvironment _env;

        public UploadFileModel (IWebHostEnvironment env)
        {
            _env = env;
        }
        public IActionResult OnPost()
        {
            var FileToUpload = Path.Combine(_env.WebRootPath, "Files", StdFile.FileName);
            Console.WriteLine("File Name: " + FileToUpload);

            using (var FStream = new FileStream(FileToUpload, FileMode.Create))
            {
                StdFile.CopyTo(FStream);

                DBConnection db = new DBConnection();
                string DbConnection = db.DbString();
                SqlConnection conn = new SqlConnection(DbConnection);
                conn.Open();
                using (SqlCommand command = new SqlCommand())
                {
                    command.Connection = conn;
                    command.CommandText = "INSERT INTO Employee (FileName) VALUES (@filename)";

                    command.Parameters.AddWithValue(FStream, GroupProject.FileName);
                    
                    Console.WriteLine(GroupProject.FileName);

                    command.ExecuteNonQuery();
                }  
            }

            return RedirectToPage("/User_Pages/UserIndex");
        }
    }
}
