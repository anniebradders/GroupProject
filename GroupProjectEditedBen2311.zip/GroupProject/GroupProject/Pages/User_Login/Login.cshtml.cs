using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.User_Login
{
    public class User_LoginModel : PageModel
    {
        [BindProperty]

        public Employee Employee { get; set; }

        public string Message { get; set; }

        public string SessionID;
        public IActionResult OnPost()
        {

            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();

            Console.WriteLine(Employee.Employee_Email);
            Console.WriteLine(Employee.Employee_Pswd);

            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"SELECT Employee_F_Name, Employee_Email, Employee_L_Name FROM Employee WHERE Employee_Email = @UName AND Employee_Pswd = @Pwd";

                command.Parameters.AddWithValue("@UName", Employee.Employee_Email);
                command.Parameters.AddWithValue("@Pwd", Employee.Employee_Pswd);

                var reader = command.ExecuteReader();

                while (reader.Read())
                {
                    Employee.Employee_F_Name = reader.GetString(0);
                    Employee.Employee_Email = reader.GetString(1);
                    Employee.Employee_Pswd = reader.GetString(2);
                }

                if (!string.IsNullOrEmpty(Employee.Employee_F_Name))
                {
                    SessionID = HttpContext.Session.Id;
                    HttpContext.Session.SetString("sessionID", SessionID);
                    HttpContext.Session.SetString("username", Employee.Employee_Email);
                    HttpContext.Session.SetString("fname", Employee.Employee_F_Name);

                    if (Employee.Employee_L_Name == "User")
                    {
                        return RedirectToPage("/User_Pages/UserIndex");
                    }
                    else
                    {
                        return RedirectToPage("/User_Pages/UserIndex");
                    }


                }
                else
                {
                    Message = "Invalid Username and Password!";
                    return Page();
                }

            }



        }
    }
}

