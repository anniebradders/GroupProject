using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Threading.Tasks;
using GroupProject.Models;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace GroupProject.Pages.Employees
{
    public class IndexModel : PageModel
    {
        [BindProperty]
        public Employee GroupProject { get; set; }
        public void OnGet()
        {
        }
        public IActionResult OnPost()
        {
            DBConnection db = new DBConnection();
            string DbConnection = db.DbString();
            SqlConnection conn = new SqlConnection(DbConnection);
            conn.Open();
            using (SqlCommand command = new SqlCommand())
            {
                command.Connection = conn;
                command.CommandText = @"INSERT INTO Employee (Employee_F_Name, Employee_L_Name, Employee_Email, Employee_Pswd) VALUES (@EFName, @ELName, @EEmail, @EPswd)";

                
                command.Parameters.AddWithValue("@EFName", GroupProject.Employee_F_Name);
                command.Parameters.AddWithValue("@ELName", GroupProject.Employee_L_Name);
                command.Parameters.AddWithValue("@EEmail", GroupProject.Employee_Email);
                command.Parameters.AddWithValue("@EPswd", GroupProject.Employee_Pswd);

                
                Console.WriteLine(GroupProject.Employee_F_Name);
                Console.WriteLine(GroupProject.Employee_L_Name);
                Console.WriteLine(GroupProject.Employee_Email);
                Console.WriteLine(GroupProject.Employee_Pswd);

                command.ExecuteNonQuery();
            }

            return RedirectToPage("/Employees/View");
        }

    }
}
